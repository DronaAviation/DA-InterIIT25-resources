#pragma once

#ifdef __cplusplus
extern "C" {
#endif 

rgbColor24bpp_t* hsvToRgb24(const hsvColor_t *c);

#ifdef __cplusplus
}
#endif 
